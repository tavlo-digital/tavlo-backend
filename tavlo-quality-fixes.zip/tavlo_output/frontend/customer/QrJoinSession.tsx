'use client';
import React from 'react';
import { Button, OtpVerificationInput, BottomSheet } from '@/components';
import Image from 'next/image';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useParams, useRouter } from 'next/navigation';
import { Assets, Navigation } from '@/constants';
import { Formik, Form, Field, FieldProps } from 'formik';
import { joinSessionSchema } from '@/utils/validation';
import { useTranslation } from 'react-i18next';
import { useQrJoinSession, useCloseTableSession } from '@/mutations';
import { toast } from 'react-hot-toast';
import { getQrData, clearQrData } from '@/utils/qr';
import { useGlobalState } from '@/providers/GlobalStateProvider';
import { AppLanguage } from '@/libs/i18n';
import { cn } from '@/utils';
import { useGetTableStatus } from '@/queries';
import { LocalStorageKey } from '@/constants';

interface QrJoinSessionProps {
  restaurantSlug: string;
}

export const QrJoinSession = ({ restaurantSlug }: QrJoinSessionProps) => {
  const router = useRouter();
  const params = useParams();
  const { t, i18n } = useTranslation();
  const { session } = useGlobalState();

  const { mutateAsync: joinSession } = useQrJoinSession();
  const { mutateAsync: closeSession, isPending: isClosing } = useCloseTableSession();
  const [isCloseSheetOpen, setIsCloseSheetOpen] = React.useState(false);

  const lng = params?.lng as AppLanguage;
  const isRtl = i18n.dir() === 'rtl';

  // Get table number: prefer live API → session → localStorage → '--'
  const { data: tableStatus } = useGetTableStatus();
  const tableNumber =
    tableStatus?.table?.number != null
      ? String(tableStatus.table.number)
      : session.tableNumber !== '--'
        ? session.tableNumber
        : (typeof window !== 'undefined'
            ? localStorage.getItem(LocalStorageKey.QrTableNumber)
            : null) ?? '--';

  const initialValues = {
    sessionCode: '',
  };

  const validationSchema = React.useMemo(() => joinSessionSchema(t), [t]);

  const { syncSession } = useGlobalState();

  const handleSubmit = async (values: typeof initialValues) => {
    const { token } = getQrData();

    if (!token) {
      toast.error(t('qr.joinSession.missingToken', 'Missing QR token. Please scan again.'));
      return;
    }

    await joinSession({ token, pin: values.sessionCode });
    syncSession();
    toast.success(t('qr.joinSession.success', 'Joined session successfully'));

    router.push(Navigation.QrCustomer.Home(lng, restaurantSlug));
  };

  const handleCloseSession = async () => {
    const { restaurantPublicId, tableId } = getQrData();

    if (!restaurantPublicId || !tableId) {
      toast.error(t('qr.joinSession.missingData', 'Missing session information.'));
      return;
    }

    try {
      await closeSession({
        vendor_public_id: restaurantPublicId,
        table_id: parseInt(tableId),
      });

      // ISSUE-026: Clear all QR session data from localStorage BEFORE redirecting.
      // Without this, the stale QrSession key causes the Welcome screen to skip
      // the scan/join flow and send the user straight to the menu — where every
      // cart API call fails with 422 "No active table session found".
      clearQrData();

      toast.success(t('qr.joinSession.closeSuccess', 'Session closed successfully'));
      setIsCloseSheetOpen(false);
      router.push(Navigation.QrCustomer.Welcome(lng, restaurantSlug));
    } catch (error) {
      const err = error as { response?: { data?: { message?: string } } };
      toast.error(
        err?.response?.data?.message || t('qr.joinSession.closeError', 'Failed to close session')
      );
    }
  };

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className={cn('flex flex-col px-6 py-6', isRtl ? 'font-sans' : 'font-montserrat')}
    >
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={() => router.push(Navigation.QrCustomer.Welcome(lng, restaurantSlug))}
          className={cn(
            'p-2 w-fit bg-secondary rounded-full transition-colors active:scale-95',
            isRtl ? '-mr-2' : '-ml-2'
          )}
        >
          {isRtl ? (
            <ChevronRight className="w-7 h-7 text-gray-800" />
          ) : (
            <ChevronLeft className="w-7 h-7 text-gray-800" />
          )}
        </button>
      </div>
      <div className="flex flex-col max-w-lg mx-auto">
        <h1 className="text-3xl font-semibold text-black900 mb-4 leading-tight tracking-tight text-center">
          {t('qr.joinSession.title')}
        </h1>
        <p className="text-black700 text-base leading-relaxed mb-12 font-medium text-center mt-2">
          {t('qr.joinSession.subtitle', { tableLabel: tableNumber })}
        </p>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ errors, touched, setFieldValue, isSubmitting }) => (
            <Form className="flex flex-col items-center w-full ">
              <div className="flex flex-col justify-center items-center gap-4 w-full">
                <Field name="sessionCode">
                  {({ field }: FieldProps) => (
                    <OtpVerificationInput
                      otp={field.value}
                      setOtp={(val) => setFieldValue('sessionCode', val)}
                      className={cn('', touched.sessionCode && errors.sessionCode && 'border-red-500')}
                    />
                  )}
                </Field>
                {touched.sessionCode && errors.sessionCode && (
                  <p
                    className={`text-red-500 text-xs mt-1 ${isRtl ? 'mr-1' : 'ml-1'} font-medium`}
                  >
                    {errors.sessionCode}
                  </p>
                )}
              </div>

              <p className="text-sm text-muted-foreground text-center mb-12 font-normal leading-relaxed mt-4">
                {t('qr.joinSession.pinInstruction')}
              </p>

              <Button type="submit" className="w-full bg-primary" isLoading={isSubmitting}>
                {t('qr.joinSession.joinButton')}
              </Button>
            </Form>
          )}
        </Formik>
        <div className="mt-8 text-center pb-20">
          <button
            type="button"
            onClick={() => setIsCloseSheetOpen(true)}
            className="text-sm font-medium text-black700 underline"
          >
            {t('qr.joinSession.startNew')}
          </button>
        </div>

        <BottomSheet open={isCloseSheetOpen} onOpenChange={setIsCloseSheetOpen} snapPoints={[0.4]}>
          <div className="flex flex-col gap-6 px-4">
            <div className="flex flex-col gap-2">
              <h2 className="text-lg font-semibold text-black900">
                {t('qr.joinSession.closeTitle', { defaultValue: 'Close Table Session' })}
              </h2>
              <p className="text-[13px] text-muted-foreground leading-relaxed font-medium">
                {t('qr.joinSession.closeDescription', {
                  defaultValue:
                    'Are you sure you want to start a new table session? This will close your current active session.',
                })}
              </p>
            </div>

            <div className="flex flex-col gap-3 mt-2">
              <Button onClick={handleCloseSession} isLoading={isClosing}>
                {t('qr.joinSession.confirmClose', { defaultValue: 'Yes, Start New Session' })}
              </Button>
              <Button variant="secondary" onClick={() => setIsCloseSheetOpen(false)}>
                {t('qr.joinSession.cancelClose', { defaultValue: 'Cancel' })}
              </Button>
            </div>
          </div>
        </BottomSheet>
        <button
          className={`fixed bottom-2 ${isRtl ? 'left-2' : 'right-2'} w-16 h-16 bg-secondary rounded-full flex items-center justify-center`}
        >
          <Image src={Assets.Images.hotelBell} className="w-8 h-8 object-contain" alt="hotel bell" width={32} height={32} />
        </button>
      </div>
    </div>
  );
};
